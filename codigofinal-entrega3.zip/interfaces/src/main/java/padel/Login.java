package padel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Login extends JFrame{
	
	List <Usuarios>usuarios = new ArrayList <Usuarios>();

	public Login() {


		leer();
		interfaz();
		
	
	
	}	
	
	
	
	//funcion de la interfaz
	public void interfaz() {
		
		//imagen del logo
		
		ImageIcon ilogo = new ImageIcon("imagenes/padel.jpg");
		Image ologo= ilogo.getImage();
		Image rlogo = ologo.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
		ImageIcon logo = new ImageIcon(rlogo);
		
		Font font = new Font("Arial", Font.PLAIN, 24);

		JFrame frame = new JFrame();
		frame.setSize(1200,900);
		frame.setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.setBackground(Color.black);
		frame.add(panel);
		
		
		//panel para colocar el logo
		
		JPanel arriba = new JPanel();
		arriba.setBackground(Color.black);
		panel.add(arriba, BorderLayout.NORTH);
		
		JButton b = new JButton(logo);
		b.setBackground(Color.black);
		b.setBorder(null);
		arriba.add(b);
		
		//panel para el login
		
		JPanel login1 = new JPanel();
		login1.setBackground(Color.black);
		login1.setLayout(new GridLayout(0,1));
		panel.add(login1, BorderLayout.CENTER);
		login1.setLayout(new GridLayout(0,1));
	   
		
		JPanel login = new JPanel();
		login.setBackground(Color.black);
		login1.add(login, BorderLayout.CENTER);
		login.setLayout(new GridLayout(0,1));
	   
		JLabel iniciar_sesion = new JLabel("INICIAR SESION");
		iniciar_sesion.setFont(font);
		iniciar_sesion.setForeground(Color.white);
		login.add(iniciar_sesion);
		
		JLabel usua = new JLabel("Usuario");
		usua.setForeground(Color.white);
		login.add(usua);
		
		JTextField usuario= new JTextField(10);
		login.add(usuario);
		
		JLabel contra = new JLabel("Contraseña");
		contra.setForeground(Color.white);
		login.add(contra);
		
		JTextField contraseña= new JTextField(10);
		login.add(contraseña);
		
		JPanel botones = new JPanel();
		login1.add(botones, BorderLayout.CENTER);
		botones.setBackground(Color.black);
		
		//botones de iniciar sesion y registrarse
		
		JButton iniciar = new JButton("Iniciar sesion");
		botones.add(iniciar);
		
		JButton registrarse = new JButton("Registrarse");
		botones.add(registrarse);
		
		
		
		
		JPanel derecha = new JPanel();
		panel.add(derecha, BorderLayout.EAST);
		derecha.setBackground(Color.black);
		
		JButton dere = new JButton("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
		dere.setForeground(Color.black);
		dere.setBackground(Color.black);
		dere.setBorder(null);
		derecha.add(dere);
		
		JPanel izquierda = new JPanel();
		panel.add(izquierda, BorderLayout.WEST);
		izquierda.setBackground(Color.black);
		
		JButton izq = new JButton("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
		izq.setForeground(Color.black);
		izq.setBackground(Color.black);
		izq.setBorder(null);
		izquierda.add(izq);
		
		
		 iniciar.addActionListener(new ActionListener(){ public void actionPerformed (){ 		
		 		
			}
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(iniciar == e.getSource()) {
				
				 String usuario1 = usuario.getText();
	             String contra1 = contraseña.getText();
	     
	      
	             //si encuentraen el txt el usuario se inicia sesion sino da error
	             
	             for(Usuarios usuario:usuarios) {
	             
	             if (usuario.getNombre().equals(usuario1) && usuario.getContraseña().equals(contra1)) {
	                 
	                 Pistas p = new Pistas();
	                 
	                 p.setVisible(true);
	                 
	                 frame.setVisible(false);  
	                       
	             } 
	             
	             } 
	             
	             if("admin".equals(usuario1) && "1234".equals(contra1)){
	                 
	                 Admin adminInterface = new Admin();
	                 
	                 adminInterface.setVisible(true);
	                 
	                 frame.setVisible(false);  
	                       
	             
	             
	             }
					
				  	}
			
		}
		
		 });
		 
			
		 registrarse.addActionListener(new ActionListener(){ public void actionPerformed (){ 		
		 		
			}
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(registrarse == e.getSource()) {
			
				
					Registrarse r = new Registrarse();
				
				  	}
			
		}
		
		 });
		
		
		
		
		
		frame.setVisible(true);
		
		
	}
	
	//funcion leer txt
	
	public void leer() {
	
		
		// La ruta del archivo de texto
	    String rutaArchivo = "usuarios.txt";
		
		 // Leer el archivo
	    try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
	        String linea;

	        // Leer cada línea del archivo
	        while ((linea = br.readLine()) != null) {
	   
	            String[] datos = linea.split(",");
	            String nombre = datos[0];
	            String contraseña = datos[1];
	            String apodo = datos[2];
	            String telefono = datos[3];
	            String email = datos[4];
	            String nivel = datos[5];
	            String mano = datos[6];
	                     

	            Usuarios usuari = new Usuarios(nombre, contraseña, apodo, email, telefono, nivel, mano);
	            usuarios.add(usuari);
	          
	        
	            
	            
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		
	}
}
