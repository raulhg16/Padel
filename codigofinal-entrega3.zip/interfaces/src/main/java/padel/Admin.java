package padel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Admin extends JFrame {
	 List<Usuarios> usuarios = new ArrayList<Usuarios>();
	 
    public Admin() {
    	

           leer();
           interfaz();
    
        
    }
    
    
    public void interfaz() {
    	//logo

        ImageIcon ilogo = new ImageIcon("imagenes/logo.webp");
        Image ologo = ilogo.getImage();
        Image rlogo = ologo.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        ImageIcon logo = new ImageIcon(rlogo);

        Color naranja = new Color(230, 105, 17);

        JFrame frame = new JFrame();
        frame.setSize(1200, 900);
    	frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(Color.black);
        panel.setLayout(new BorderLayout());
        frame.add(panel);

        // Menu de arriba para el botón "Añadir jugador"
        JPanel menu = new JPanel();
        panel.add(menu, BorderLayout.NORTH);

        JButton boton = new JButton("Añadir jugador");
        menu.setBackground(Color.black);
        menu.setSize(1000, 50);
        menu.setBackground(naranja);
        menu.add(boton);

        // Panel para mostrar los usuarios de la página
        Panel usua = new Panel();
        panel.add(usua, BorderLayout.CENTER);

        for (Usuarios usuario : usuarios) {
            JButton b = new JButton(usuario.toString());
            usua.add(b);

            // Acción para cada botón de usuario (Eliminar o Reservar)
            b.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	
                    // Crear el JDialog para elegir entre Eliminar o Reservar
                    JDialog dialog = new JDialog(frame, "Opciones de Usuario", true);
                    dialog.setLayout(new GridLayout(2, 1));
                    dialog.setSize(250, 150);

                    // Botones de eliminar o reservar
                    JButton eliminarButton = new JButton("Eliminar usuario");
                    JButton reservarButton = new JButton("Reservar");
                    dialog.add(eliminarButton);
                    dialog.add(reservarButton);

                    // Acción para eliminar el usuario
                    eliminarButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                      
                            usuarios.remove(usuario);  // Elimina el usuario de la lista
                            usua.remove(b);  // Elimina el botón de la interfaz
                            usua.revalidate();  // Refresca el panel
                            usua.repaint();  // Repinta el panel

                            dialog.dispose();  // Cierra el diálogo
                        }
                    });

                    // Acción para reservar una pista
                    reservarButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            // Redirigir al usuario a la interfaz de pistas
                            Pistas p = new Pistas();
                            p.setVisible(true);
                            dialog.dispose();  // Cierra el diálogo
                        }
                    });

                    dialog.setVisible(true);  // Mostrar el diálogo
                }
            });
        }

        // Acción para el botón "Añadir jugador"
        boton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear el JDialog para añadir un nuevo usuario
                JDialog dialog = new JDialog(frame, "Añadir nuevo jugador", true);
                dialog.setSize(300, 300);
                dialog.setLayout(new GridLayout(0, 1));  // Crear una cuadrícula para los campos de texto y etiquetas

                // Crear los campos de texto para ingresar los datos
                JTextField nombreField = new JTextField();
                JTextField contraseñafield = new JTextField();
                JTextField apodoField = new JTextField();
                JTextField nivelField = new JTextField();
                JTextField telefonoField = new JTextField();
                JTextField correoField = new JTextField();
                JTextField manoField = new JTextField();

                // Agregar etiquetas y campos de texto
                dialog.add(new JLabel("Nombre:"));
                dialog.add(nombreField);
                dialog.add(new JLabel("Contraseña:"));
                dialog.add(contraseñafield);
                dialog.add(new JLabel("Apodo:"));
                dialog.add(apodoField);
                dialog.add(new JLabel("Nivel:"));
                dialog.add(nivelField);
                dialog.add(new JLabel("Teléfono:"));
                dialog.add(telefonoField);
                dialog.add(new JLabel("Correo:"));
                dialog.add(correoField);
                dialog.add(new JLabel("Zurdo/Diestro:"));
                dialog.add(manoField);

                // Botones para aceptar o cancelar
                JButton aceptarButton = new JButton("Aceptar");
                JButton cancelarButton = new JButton("Cancelar");

                dialog.add(aceptarButton);
                dialog.add(cancelarButton);

                // Acción del botón "Aceptar"
                aceptarButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String nombre = nombreField.getText();
                        String contraseña = contraseñafield.getText();
                        String apodo = apodoField.getText();
                        String nivel = nivelField.getText();
                        String telefono = telefonoField.getText();
                        String correo = correoField.getText();
                        String mano = manoField.getText();
                        
                     // Crear el nuevo usuario y añadirlo a la lista
                        Usuarios nuevoUsuario = new Usuarios(nombre, contraseña, apodo, telefono, correo, nivel, mano);
                        usuarios.add(nuevoUsuario);
                        
                        // Escribir el nuevo usuario en el archivo de texto
                        try (BufferedWriter writer = new BufferedWriter(new FileWriter("usuarios.txt", true))) {
                            // Escribir un salto de línea para asegurar que se inserte en la siguiente línea
                            if (new java.io.File("usuarios.txt").length() > 0) {
                                writer.newLine();  // Escribir nueva línea si el archivo ya tiene contenido
                            }
                            // Escribir los datos del usuario en el archivo en formato CSV
                            writer.write(nombre + "," + contraseña + "," + apodo + "," + telefono + "," + correo + "," + nivel + "," + mano);
                        } catch (IOException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(dialog, "Error al guardar el usuario.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                        
                        
                        
                        

                        

                        // Crear un nuevo botón para el usuario
                        JButton botonUsuario = new JButton(nuevoUsuario.toString());
                        usua.add(botonUsuario);
                        usua.revalidate();  // Refresca la interfaz
                        usua.repaint();  // Repinta el panel

                        dialog.dispose();  // Cerrar el diálogo
                    }
                });

                // Acción del botón "Cancelar"
                cancelarButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        dialog.dispose();  // Cerrar el diálogo sin hacer nada
                    }
                });

                dialog.setVisible(true);  // Mostrar el diálogo
            }
        });

        // Configuración del marco (ventana)
        frame.setVisible(true);
    	
    	
    }
    
    
    
    
  //funcion leer txt
	
  	public void leer() {
  	
  		
  		// La ruta del archivo de texto
  	    String rutaArchivo = "usuarios.txt";
  		
  		 // Leer el archivo
  	    try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
  	        String linea;

  	        // Leer cada línea del archivo
  	        while ((linea = br.readLine()) != null) {
  	   
  	            String[] datos = linea.split(",");
  	            String nombre = datos[0];
  	            String contraseña = datos[1];
  	            String apodo = datos[2];
  	            String telefono = datos[3];
  	            String email = datos[4];
  	            String nivel = datos[5];
  	            String mano = datos[6];
  	                     

  	            Usuarios usuari = new Usuarios(nombre, contraseña, apodo, email, telefono, nivel, mano);
  	            usuarios.add(usuari);
  	          
  	        
  	            
  	            
  	        }
  	    } catch (IOException e) {
  	        e.printStackTrace();
  	    }
  		
  	}
}
