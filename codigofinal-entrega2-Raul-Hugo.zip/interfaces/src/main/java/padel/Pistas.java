package padel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
public class Pistas extends JFrame{
  public Pistas(){
	  
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Nuestras pistas de padel");
            frame.setSize(1200, 900);
 
            //panel principal con el fondo negro
            JPanel PanelP = new JPanel(new BorderLayout());
            PanelP.setBackground(Color.BLACK);
 
            //panel pequeño para poner la imagen
            JPanel topLeftPanel = new JPanel();
            topLeftPanel.setBackground(Color.BLACK); 
            topLeftPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10)); 
 
            // Logo
            JLabel logo = new JLabel();
            ImageIcon logoPadel = new ImageIcon("imagenes/padelCiudadRodrigo.webp");
            logo.setIcon(new ImageIcon(logoPadel.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH)));
            topLeftPanel.add(logo);
 
            //añadir imagen logo
            PanelP.add(topLeftPanel, BorderLayout.NORTH);
 
            //Panel secundario
            JPanel Panel2 = new JPanel();
            Panel2.setLayout(new GridLayout(2, 2, 10, 10));
            Panel2.setBackground(Color.BLACK);
 
            // Panel 1
            JPanel panel1 = new JPanel(new BorderLayout());
            panel1.setBackground(Color.BLACK);
            JButton boton1 = new JButton();
            ImageIcon pista1 = new ImageIcon("imagenes/padel5.jpg");
            boton1.setIcon(new ImageIcon(pista1.getImage().getScaledInstance(400, 300, Image.SCALE_SMOOTH)));
            boton1.setFocusPainted(false);
            boton1.setContentAreaFilled(false);
            boton1.setBorderPainted(false);
            JLabel label1 = new JLabel("Pista Milar", SwingConstants.CENTER);
            label1.setFont(new Font("Arial", Font.PLAIN, 20));
            label1.setForeground(Color.WHITE);
            panel1.add(boton1, BorderLayout.CENTER);
            panel1.add(label1, BorderLayout.SOUTH);
 
            // Panel 2
            JPanel panel2 = new JPanel(new BorderLayout());
            panel2.setBackground(Color.BLACK);
            JButton boton2 = new JButton();
            ImageIcon pista2 = new ImageIcon("imagenes/padel2.jpg");
            boton2.setIcon(new ImageIcon(pista2.getImage().getScaledInstance(400, 300, Image.SCALE_SMOOTH)));
            boton2.setFocusPainted(false);
            boton2.setContentAreaFilled(false);
            boton2.setBorderPainted(false);
            JLabel label2 = new JLabel("Pista Jamones Jamugo", SwingConstants.CENTER);
            label2.setFont(new Font("Arial", Font.PLAIN, 20));
            label2.setForeground(Color.WHITE);
            panel2.add(boton2, BorderLayout.CENTER);
            panel2.add(label2, BorderLayout.SOUTH);
 
            // Panel 3
            JPanel panel3 = new JPanel(new BorderLayout());
            panel3.setBackground(Color.BLACK);
            JButton boton3 = new JButton();
            ImageIcon pista3 = new ImageIcon("imagenes/padel3.jpg");
            boton3.setIcon(new ImageIcon(pista3.getImage().getScaledInstance(400, 300, Image.SCALE_SMOOTH)));
            boton3.setFocusPainted(false);
            boton3.setContentAreaFilled(false);
            boton3.setBorderPainted(false);
            JLabel label3 = new JLabel("Pista Wilson", SwingConstants.CENTER);
            label3.setFont(new Font("Arial", Font.PLAIN, 20));
            label3.setForeground(Color.WHITE);
            panel3.add(boton3, BorderLayout.CENTER);
            panel3.add(label3, BorderLayout.SOUTH);
 
            // Panel 4
            JPanel panel4 = new JPanel(new BorderLayout());
            panel4.setBackground(Color.BLACK);
            JButton boton4 = new JButton();
            ImageIcon pista4 = new ImageIcon("imagenes/padel4.png");
            boton4.setIcon(new ImageIcon(pista4.getImage().getScaledInstance(400, 300, Image.SCALE_SMOOTH)));
            boton4.setFocusPainted(false);
            boton4.setContentAreaFilled(false);
            boton4.setBorderPainted(false);
            JLabel label4 = new JLabel("Pista Muebles Fernandez", SwingConstants.CENTER);
            label4.setFont(new Font("Arial", Font.PLAIN, 20));
            label4.setForeground(Color.WHITE);
            panel4.add(boton4, BorderLayout.CENTER);
            panel4.add(label4, BorderLayout.SOUTH);
 
            // añade los cuatro paaneles al secundario
            Panel2.add(panel1);
            Panel2.add(panel2);
            Panel2.add(panel3);
            Panel2.add(panel4);
 
            // añade el panel secundario a el principal
            PanelP.add(Panel2, BorderLayout.CENTER);
 
            frame.add(PanelP);
            
            boton1.addActionListener(new ActionListener(){ public void actionPerformed (){ 		
    	 		
	 		}
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(boton1 == e.getSource()) {
				
				Pista p = new Pista();			
				
			}
			
		}
		
		 });
            
            
            boton2.addActionListener(new ActionListener(){ public void actionPerformed (){ 		
    	 		
	 		}
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(boton2 == e.getSource()) {
				
				Pista p = new Pista();			
				
			}
			
		}
		
		 });
            
            
            boton3.addActionListener(new ActionListener(){ public void actionPerformed (){ 		
    	 		
	 		}
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(boton3 == e.getSource()) {
				
				Pista p = new Pista();			
				
			}
			
		}
		
		 });
            
            
            boton4.addActionListener(new ActionListener(){ public void actionPerformed (){ 		
    	 		
	 		}
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(boton4 == e.getSource()) {
				
				Pista p = new Pista();			
				
			}
			
		}
		
		 });

           
       
            frame.setVisible(true);
        });
    }
}