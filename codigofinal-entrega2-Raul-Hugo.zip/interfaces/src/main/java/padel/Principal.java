package padel;




public class Principal {

	public static void main(String[] args) {
		
		//administrador: admin  contraseña:1234
		//usuario:juan   contraseña:12345
		
		
		
		Login l = new Login();
	


}
	
	
}
