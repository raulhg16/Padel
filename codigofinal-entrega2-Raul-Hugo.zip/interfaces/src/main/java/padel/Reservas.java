package padel;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Reservas extends JFrame {

    public Reservas() {
        JDialog dialog = new JDialog(this, "Reservar Pista");
        dialog.setLayout(new GridLayout(6, 1));  
        dialog.setSize(300, 300);

        // Etiqueta de días
        JLabel diasLabel = new JLabel("Selecciona un día:");
        dialog.add(diasLabel);

        // Días disponibles
        
        String[] dias = {"Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
        JComboBox<String> diasCombo = new JComboBox<>(dias);
        dialog.add(diasCombo);

        // Etiqueta de horas
        
        JLabel horasLabel = new JLabel("Selecciona una hora:");
        dialog.add(horasLabel);

        // Horas disponibles para días lunes a viernes
        
        String[] horasCompletas = {"16:00-17:30", "17:30-19:00", "19:00-20:30", "20:30-22:00"};
        String[] horasFinDeSemana = {"10:00-11:30", "11:30-13:00"};  // Horas limitadas para Sábado y Domingo

        // JComboBox para las horas (completas inicialmente)
        
        JComboBox<String> horasCombo = new JComboBox<>(horasCompletas);
        dialog.add(horasCombo);

        // Botón para realizar la reserva
        JButton reservarButton = new JButton("Reservar");
        dialog.add(reservarButton);

        // Acción al pulsar el botón "Reservar"
        reservarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Mostrar mensaje de reserva exitosa
                JOptionPane.showMessageDialog(dialog, "Reserva realizada correctamente para el " +
                        diasCombo.getSelectedItem() + " a las " + horasCombo.getSelectedItem(),
                        "Reserva Confirmada", JOptionPane.INFORMATION_MESSAGE);

                dialog.dispose();  // Cerrar el diálogo
            }
        });

        // Acción cuando se selecciona un día
        diasCombo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el día seleccionado
            	
                String diaSeleccionado = (String) diasCombo.getSelectedItem();

                // Si el día es Sábado o Domingo, actualizar las horas disponibles
                
                if (diaSeleccionado.equals("Sábado") || diaSeleccionado.equals("Domingo")) {
                    horasCombo.setModel(new JComboBox<>(horasFinDeSemana).getModel());
                } else {
                    // Si el día es de lunes a viernes, mostrar todas las horas
                	
                    horasCombo.setModel(new JComboBox<>(horasCompletas).getModel());
                }
            }
        });

        dialog.setVisible(true);  // Mostrar el diálogo
    }
}
