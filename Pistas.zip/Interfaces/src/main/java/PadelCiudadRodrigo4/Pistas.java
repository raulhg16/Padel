package PadelCiudadRodrigo4;
import javax.swing.*;
import java.awt.*;
 
public class Pistas {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Nuestras pistas de padel");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Fullscreen-like behavior
            frame.setSize(1200, 900);
 
            // Main panel with black background
            JPanel mainPanel = new JPanel(new BorderLayout());
            mainPanel.setBackground(Color.BLACK);
 
            // Top-left corner panel for the small image
            JPanel topLeftPanel = new JPanel();
            topLeftPanel.setBackground(Color.BLACK); // Match the background
            topLeftPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10)); // Small margin from edges
 
            // Small image
            JLabel logo = new JLabel();
            ImageIcon smallIcon = new ImageIcon("imagenes/padelCiudadRodrigo.webp"); // Replace with your image path
            logo.setIcon(new ImageIcon(smallIcon.getImage().getScaledInstance(25, 25, Image.SCALE_SMOOTH)));
            topLeftPanel.add(logo);
 
            // Add the small image panel to the top-left
            mainPanel.add(topLeftPanel, BorderLayout.NORTH);
 
            // Center panel with grid layout for images and labels
            JPanel gridPanel = new JPanel();
            gridPanel.setLayout(new GridLayout(2, 2, 10, 10));
            gridPanel.setBackground(Color.BLACK);
 
            // Panel 1: Image and Label
            JPanel panel1 = new JPanel(new BorderLayout());
            panel1.setBackground(Color.BLACK);
            JButton button1 = new JButton();
            ImageIcon icon1 = new ImageIcon("imagenes/padel.jpg");
            button1.setIcon(new ImageIcon(icon1.getImage().getScaledInstance(400, 300, Image.SCALE_SMOOTH)));
            button1.setFocusPainted(false);
            button1.setContentAreaFilled(false);
            button1.setBorderPainted(false);
            JLabel label1 = new JLabel("Pista Milar", SwingConstants.CENTER);
            label1.setFont(new Font("Arial", Font.PLAIN, 20));
            label1.setForeground(Color.WHITE);
            panel1.add(button1, BorderLayout.CENTER);
            panel1.add(label1, BorderLayout.SOUTH);
 
            // Panel 2: Image and Label
            JPanel panel2 = new JPanel(new BorderLayout());
            panel2.setBackground(Color.BLACK);
            JButton button2 = new JButton();
            ImageIcon icon2 = new ImageIcon("imagenes/padel2.jpg");
            button2.setIcon(new ImageIcon(icon2.getImage().getScaledInstance(400, 300, Image.SCALE_SMOOTH)));
            button2.setFocusPainted(false);
            button2.setContentAreaFilled(false);
            button2.setBorderPainted(false);
            JLabel label2 = new JLabel("Pista Jamones Jamugo", SwingConstants.CENTER);
            label2.setFont(new Font("Arial", Font.PLAIN, 20));
            label2.setForeground(Color.WHITE);
            panel2.add(button2, BorderLayout.CENTER);
            panel2.add(label2, BorderLayout.SOUTH);
 
            // Panel 3: Image and Label
            JPanel panel3 = new JPanel(new BorderLayout());
            panel3.setBackground(Color.BLACK);
            JButton button3 = new JButton();
            ImageIcon icon3 = new ImageIcon("imagenes/padel3.jpg");
            button3.setIcon(new ImageIcon(icon3.getImage().getScaledInstance(400, 300, Image.SCALE_SMOOTH)));
            button3.setFocusPainted(false);
            button3.setContentAreaFilled(false);
            button3.setBorderPainted(false);
            JLabel label3 = new JLabel("Pista Wilson", SwingConstants.CENTER);
            label3.setFont(new Font("Arial", Font.PLAIN, 20));
            label3.setForeground(Color.WHITE);
            panel3.add(button3, BorderLayout.CENTER);
            panel3.add(label3, BorderLayout.SOUTH);
 
            // Panel 4: Image and Label
            JPanel panel4 = new JPanel(new BorderLayout());
            panel4.setBackground(Color.BLACK);
            JButton button4 = new JButton();
            ImageIcon icon4 = new ImageIcon("imagenes/padel4.png");
            button4.setIcon(new ImageIcon(icon4.getImage().getScaledInstance(400, 300, Image.SCALE_SMOOTH)));
            button4.setFocusPainted(false);
            button4.setContentAreaFilled(false);
            button4.setBorderPainted(false);
            JLabel label4 = new JLabel("Pista Muebles Fernandez", SwingConstants.CENTER);
            label4.setFont(new Font("Arial", Font.PLAIN, 20));
            label4.setForeground(Color.WHITE);
            panel4.add(button4, BorderLayout.CENTER);
            panel4.add(label4, BorderLayout.SOUTH);
 
            // Add all panels to the grid
            gridPanel.add(panel1);
            gridPanel.add(panel2);
            gridPanel.add(panel3);
            gridPanel.add(panel4);
 
            // Add grid panel to the center of the main panel
            mainPanel.add(gridPanel, BorderLayout.CENTER);
 
            frame.add(mainPanel);
            frame.setVisible(true);
        });
    }
}