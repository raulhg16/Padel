package padel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Admin extends JFrame{

	public Admin() {
		
		Color naranja = new Color(230, 105, 17);
		
		JFrame frame = new JFrame();
		frame.setSize(1200,900);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.black);
		panel.setLayout(new BorderLayout());
		frame.add(panel);
		
		
		JPanel menu = new JPanel();
		panel.add(menu,BorderLayout.NORTH);
		
		
		JButton boton = new JButton ("Añadir jugador");
		menu.setBackground(Color.black);
		menu.setSize(1000,50);
		menu.setBackground(naranja);
		menu.add(boton);
		
		Panel usuarios = new Panel();
		panel.add(usuarios, BorderLayout.CENTER);
		
		JButton b = new JButton("Paco Gonzalez Snachez  Apodo: El pedro  Nivel: 2  Telefono: 666 66 66 66  Correo: pedro@gmail.com  Zurdo ");
		usuarios.add(b);
		usuarios.add(new JButton("Paco Gonzalez Snachez  Apodo: El pedro  Nivel: 2  Telefono: 666 66 66 66  Correo: pedro@gmail.com  Zurdo "));
		usuarios.add(new JButton("Paco Gonzalez Snachez  Apodo: El pedro  Nivel: 2  Telefono: 666 66 66 66  Correo: pedro@gmail.com  Zurdo "));
		usuarios.add(new JButton("Paco Gonzalez Snachez  Apodo: El pedro  Nivel: 2  Telefono: 666 66 66 66  Correo: pedro@gmail.com  Zurdo "));
		usuarios.add(new JButton("Paco Gonzalez Snachez  Apodo: El pedro  Nivel: 2  Telefono: 666 66 66 66  Correo: pedro@gmail.com  Zurdo "));
		usuarios.add(new JButton("Paco Gonzalez Snachez  Apodo: El pedro  Nivel: 2  Telefono: 666 66 66 66  Correo: pedro@gmail.com  Zurdo "));
		
		
		 b.addActionListener(new ActionListener(){ public void actionPerformed (){ 		
	 		
	 		}
		@Override
		public void actionPerformed(ActionEvent e) {
			
			if(b == e.getSource()) {
				
				
				JDialog dialog = new JDialog();
				dialog.setLayout(new GridLayout(0,1));
				dialog.setSize(200,200);
			
				
				JButton eliminar = new JButton("Eliminar usuario");
				JButton reservar = new JButton("Reservar");
				
				dialog.add(eliminar);
				dialog.add(reservar);
				
				dialog.setVisible(true);
				
				 reservar.addActionListener(new ActionListener(){ public void actionPerformed (){ 		
				 		
			 		}
				@Override
				public void actionPerformed(ActionEvent e) {
					
					if(reservar == e.getSource()) {
						
						
						Pistas p = new Pistas();
						
						
					}
					
				}
				
				 });
				 
				
				
			}
			
		}
		
		 });
		 
		 
	

	 		
		
	 		
		frame.setVisible(true);
		
	}
	
	
}
