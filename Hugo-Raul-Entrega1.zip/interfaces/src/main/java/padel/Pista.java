package padel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class Pista {

	public Pista() {
		
		ImageIcon ipersona = new ImageIcon("imagenes/per.png");
		Image opersona = ipersona.getImage();
		Image rpersona = opersona.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
		ImageIcon persona = new ImageIcon(rpersona);
		
		JFrame frame = new JFrame();
		frame.setSize(1200,900);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.black);
		panel.setLayout(new BorderLayout());
		frame.add(panel);
			
		
		JPanel centro = new JPanel();
		centro.setBackground(Color.black);
		panel.add(centro, BorderLayout.CENTER);
		centro.setLayout(new GridLayout(2,2));
		
		Border borde = BorderFactory.createLineBorder(Color.BLACK, 5);
		
		JPanel j1 = new JPanel();
		j1.setLayout(new BorderLayout());
		j1.setBackground(Color.white);
		j1.setBorder(borde);
		centro.add(j1);
		
		JButton p1 = new JButton(persona);
		p1.setBackground(Color.white);
		p1.setBorder(null);
		j1.add(p1, BorderLayout.CENTER);
		
		
		JPanel j2 = new JPanel();
		centro.add(j2);
		j2.setBackground(Color.white);
		j2.setBorder(borde);
		j2.setLayout(new BorderLayout());
		
		JButton p2 = new JButton(persona);
		p2.setBackground(Color.white);
		p2.setBorder(null);
		j2.add(p2, BorderLayout.CENTER);
		
		
		JPanel j3 = new JPanel();
		centro.add(j3);
		j3.setBackground(Color.white);
		j3.setBorder(borde);
		j3.setLayout(new BorderLayout());
		
		JButton p3 = new JButton(persona);
		p3.setBackground(Color.white);
		p3.setBorder(null);
		j3.add(p3, BorderLayout.CENTER);
		
		
		JPanel j4 = new JPanel();
		centro.add(j4);
		j4.setBackground(Color.white);
		j4.setBorder(borde);
		j4.setLayout(new BorderLayout());
		
		JButton p4 = new JButton(persona);
		p4.setBackground(Color.white);
		p4.setBorder(null);
		j4.add(p4, BorderLayout.CENTER);
		
		
		
		frame.setVisible(true);
	}
	
}
