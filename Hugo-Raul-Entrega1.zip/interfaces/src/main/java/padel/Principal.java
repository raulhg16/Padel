package padel;

public class Principal {

	public static void main(String[] args) {
		
		Admin a = new Admin();
		Pistas p =new  Pistas();
	

	}

}
