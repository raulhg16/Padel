package padel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Registrarse {
	
	List <Usuarios>usuarios = new ArrayList <Usuarios>();
	
	public Registrarse() {
		
		//imagen del logo
		
		ImageIcon ilogo = new ImageIcon("imagenes/padel.jpg");
		Image ologo= ilogo.getImage();
		Image rlogo = ologo.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
		ImageIcon logo = new ImageIcon(rlogo);
		
		Font font = new Font("Arial", Font.PLAIN, 24);

		JFrame frame = new JFrame();
		frame.setSize(1200,900);
		
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.setBackground(Color.black);
		frame.add(panel);
		
		
		//panel para colocar el logo
		
		JPanel arriba = new JPanel();
		arriba.setBackground(Color.black);
		panel.add(arriba, BorderLayout.NORTH);
		
		JButton b = new JButton(logo);
		b.setBackground(Color.black);
		b.setBorder(null);
		arriba.add(b);
		
		//panel para el login
	   
		
		JPanel login = new JPanel();
		login.setBackground(Color.black);
		panel.add(login, BorderLayout.CENTER);
		login.setLayout(new GridLayout(0,1));
	   
		JLabel iniciar_sesion = new JLabel("REGISTRARSE");
		iniciar_sesion.setFont(font);
		iniciar_sesion.setForeground(Color.white);
		login.add(iniciar_sesion);
		
		JLabel usu = new JLabel("Usuario");
		usu.setForeground(Color.white);
		login.add(usu);
		
		JTextField usuario= new JTextField(10);
		login.add(usuario);
		
		JLabel contra = new JLabel("Contraseña");
		contra.setForeground(Color.white);
		login.add(contra);
		
		JTextField contraseña= new JTextField(10);
		login.add(contraseña);
		
		JLabel apo = new JLabel("Apodo");
		apo.setForeground(Color.white);
		login.add(apo);
		
		JTextField apodo= new JTextField(10);
		login.add(apodo);
		
		JLabel ema = new JLabel("Email");
		ema.setForeground(Color.white);
		login.add(ema);
		
		JTextField email= new JTextField(10);
		login.add(email);
		
		JLabel tele = new JLabel("Telefono");
		tele.setForeground(Color.white);
		login.add(tele);
		
		JTextField telefono= new JTextField(10);
		login.add(telefono);
		
		JLabel niv = new JLabel("Nivel");
		niv.setForeground(Color.white);
		login.add(niv);
		
		JComboBox <String> nivel = new JComboBox<String>();
		String facil="facil";
		nivel.addItem(facil);
		String medio = "medio";
		nivel.addItem(medio);
		String avanzado="avanzado";
		nivel.addItem(avanzado);
		login.add(nivel);
		
		
		JCheckBox zurdo = new JCheckBox("Zurdo");
		zurdo.setBackground(Color.black);
		zurdo.setForeground(Color.white);
		login.add(zurdo);
		JCheckBox diestro = new JCheckBox("Diestro");
		diestro.setBackground(Color.black);
		diestro.setForeground(Color.white);
		login.add(diestro);
		
		JPanel botones = new JPanel();
		panel.add(botones, BorderLayout.SOUTH);
		botones.setBackground(Color.black);
		
		JButton registrarse = new JButton("Registrarse");
		botones.add(registrarse);
		
		
		JPanel derecha = new JPanel();
		panel.add(derecha, BorderLayout.EAST);
		derecha.setBackground(Color.black);
		
		JButton dere = new JButton("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
		dere.setForeground(Color.black);
		dere.setBackground(Color.black);
		dere.setBorder(null);
		derecha.add(dere);
		
		JPanel izquierda = new JPanel();
		panel.add(izquierda, BorderLayout.WEST);
		izquierda.setBackground(Color.black);
		
		JButton izq = new JButton("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
		izq.setForeground(Color.black);
		izq.setBackground(Color.black);
		izq.setBorder(null);
		izquierda.add(izq);
		
		
		
		
		 registrarse.addActionListener(new ActionListener(){ public void actionPerformed (){ 		
		 		
			}
		@Override
		public void actionPerformed(ActionEvent e) {
			
				
				String usuario1 = usuario.getText();
				String contraseña1 = contraseña.getText();
				String apodo1 = apodo.getText();
				String telefono1 = telefono.getText();
				String email1 = email.getText();	
				
				
				  boolean error = false;
	                
	                // Limpiar colores de etiquetas
	                usu.setForeground(Color.white);
	                contra.setForeground(Color.white);
	                apo.setForeground(Color.white);
	                ema.setForeground(Color.white);
	                tele.setForeground(Color.white);
	                
	                // Verificar si algún campo está vacío
	                if (usuario1.isEmpty()) {
	                    usu.setForeground(Color.red);
	                    error = true;
	                }
	                if (contraseña1.isEmpty()) {
	                    contra.setForeground(Color.red);
	                    error = true;
	                }
	                if (apodo1.isEmpty()) {
	                    apo.setForeground(Color.red);
	                    error = true;
	                }
	                if (telefono1.isEmpty()) {
	                    tele.setForeground(Color.red);
	                    error = true;
	                }
	                if (email1.isEmpty()) {
	                    ema.setForeground(Color.red);
	                    error = true;
	                }
	                
	                // Si hay error, mostrar mensaje y no continuar
	                if (error) {
	                    JOptionPane.showMessageDialog(registrarse, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
	                } else {
	                    // Si no hay error, proceder con el registro
	                    Usuarios u = new Usuarios(usuario1, contraseña1, apodo1, telefono1, email1, null, null);
	                    usuarios.add(u);
	                    
	                    // Escribir el nuevo usuario en el archivo de texto
                        try (BufferedWriter writer = new BufferedWriter(new FileWriter("usuarios.txt", true))) {
                            // Escribir un salto de línea para asegurar que se inserte en la siguiente línea
                            if (new java.io.File("usuarios.txt").length() > 0) {
                                writer.newLine();  // Escribir nueva línea si el archivo ya tiene contenido
                            }
                            // Escribir los datos del usuario en el archivo en formato CSV
                            writer.write(usuario1 + "," + contraseña1 + "," + apodo1 + "," + telefono1 + "," + email + ",null, null");
                        } catch (IOException ex) {
                            ex.printStackTrace();
                      
                        }
	                    
	                    // Aquí puedes abrir la siguiente pantalla (por ejemplo Pistas)
	                    Pistas p = new Pistas();
	                    p.setVisible(true);
	                    
	                    Login l = new Login();
	                    l.setVisible(false);
	                    		
	                    
	                    // Cerrar la ventana actual
	                    frame.dispose();
	                }
	            }
	        });
				
			
				
			
	
		
		
		
		
		
		frame.setVisible(true);
		
	}

}
